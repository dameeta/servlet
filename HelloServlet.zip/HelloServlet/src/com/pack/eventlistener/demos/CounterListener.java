package com.pack.eventlistener.demos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;


@WebListener
public class CounterListener implements ServletContextListener {

    ServletContext contx;
    Connection con;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
    int count;
    
    public void contextInitialized(ServletContextEvent ent)
    {
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/coforgedata","root","root");
    		st = con.createStatement();
    		rs=st.executeQuery("select visitor from countvisitor");
    		while(rs.next()) {
    			count=rs.getInt(1);
    		}
    		contx =ent.getServletContext();
    		contx.setAttribute("vcount", count);
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    public void contextDestroyed(ServletContextEvent scv)
    {
    	try {
    		contx = scv.getServletContext();
    		count=(Integer)contx.getAttribute("vcount");
    		ps = con.prepareStatement("update countvisitor set visitor='" + count+ "'");
    		ps.executeUpdate();
    		
    		
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    
	
}
